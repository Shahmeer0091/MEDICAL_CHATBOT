"""
app.py — Real-Time House Price Prediction Web App
Flask backend with live data streaming, scheduler, and REST API
"""

import os, json, threading, time, logging
from datetime import datetime

import pandas as pd
from flask import (Flask, render_template, request,
                   jsonify, Response, stream_with_context)

from utils  import (simulate_one_record, compute_trends,
                    generate_initial_dataset, LOCATIONS)
from model  import train, predict_price, load_model, DATA_PATH

# ─── App setup ───────────────────────────────────────────────────────────────

app = Flask(__name__)
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

# Thread-safe buffer for the live stream (SSE)
_stream_buffer   = []
_buffer_lock     = threading.Lock()
_scheduler_ready = threading.Event()

# ─── Background scheduler (simulates real-time data feed) ────────────────────

def _data_fetcher():
    """
    Runs in a daemon thread.
    Every 10 seconds: generate a new synthetic listing,
    append to CSV, push to SSE buffer.
    Every 50 new rows: auto-retrain model.
    """
    new_rows_since_retrain = 0
    _scheduler_ready.set()
    log.info("⏰  Data fetcher scheduler started (interval=10s)")

    while True:
        try:
            record = simulate_one_record()
            row_df = pd.DataFrame([record])

            # Append to persistent CSV
            header = not os.path.exists(DATA_PATH)
            row_df.to_csv(DATA_PATH, mode="a", header=header, index=False)

            # Push to SSE buffer (keep last 100)
            with _buffer_lock:
                _stream_buffer.append(record)
                if len(_stream_buffer) > 100:
                    _stream_buffer.pop(0)

            new_rows_since_retrain += 1
            log.debug(f"New listing: {record['location']} "
                      f"| PKR {record['price_pkr']:,.0f}")

            # Auto-retrain every 50 new records
            if new_rows_since_retrain >= 50:
                log.info("🔄  Auto-retrain triggered (50 new rows)")
                train()
                new_rows_since_retrain = 0

        except Exception as exc:
            log.error(f"Fetcher error: {exc}")

        time.sleep(10)


# ─── Routes ──────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    _, _, _, metrics = load_model()
    return render_template("index.html",
                           locations=LOCATIONS,
                           metrics=metrics)


@app.route("/api/predict", methods=["POST"])
def api_predict():
    """Instant price prediction from form inputs."""
    try:
        data = request.get_json(force=True)
        features = {
            "area_sqyd":  float(data["area_sqyd"]),
            "bedrooms":   int(data["bedrooms"]),
            "bathrooms":  int(data["bathrooms"]),
            "year_built": int(data["year_built"]),
            "floors":     int(data["floors"]),
            "garage":     int(data.get("garage", 0)),
            "has_garden": int(data.get("has_garden", 0)),
            "location":   str(data["location"]),
        }
        price = predict_price(features)
        return jsonify({"price_pkr": price, "status": "ok"})
    except Exception as exc:
        log.error(f"/api/predict error: {exc}")
        return jsonify({"error": str(exc), "status": "error"}), 400


@app.route("/api/trends")
def api_trends():
    """Return current market trends JSON."""
    try:
        if not os.path.exists(DATA_PATH):
            return jsonify({"error": "No data yet"}), 503
        df = pd.read_csv(DATA_PATH)
        return jsonify(compute_trends(df))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/retrain", methods=["POST"])
def api_retrain():
    """Manually trigger model retraining."""
    try:
        log.info("Manual retrain requested via API")
        metrics = train()
        return jsonify({"status": "ok", "metrics": metrics})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/stream")
def api_stream():
    """
    Server-Sent Events endpoint.
    Pushes new listings to the browser every 10 s.
    """
    def generate():
        last_seen = 0
        while True:
            with _buffer_lock:
                new_items = _stream_buffer[last_seen:]
                last_seen = len(_stream_buffer)
            for item in new_items:
                yield f"data: {json.dumps(item)}\n\n"
            time.sleep(3)

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache",
                 "X-Accel-Buffering": "no"})


@app.route("/api/model-info")
def api_model_info():
    """Return current model metadata."""
    try:
        _, _, _, metrics = load_model()
        return jsonify(metrics)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ─── Startup ─────────────────────────────────────────────────────────────────

def _bootstrap():
    """Train model if not already saved, then start scheduler."""
    from model import MODEL_PATH
    if not os.path.exists(MODEL_PATH):
        log.info("🚀  First run — training initial model …")
        train()
    else:
        log.info("✅  Existing model found, skipping initial training.")

    t = threading.Thread(target=_data_fetcher, daemon=True)
    t.start()
    _scheduler_ready.wait()


if __name__ == "__main__":
    _bootstrap()
    app.run(debug=False, host="0.0.0.0", port=5000, threaded=True)
