"""
model.py — ML pipeline: train, evaluate, save, load
Supports Random Forest (default) and XGBoost.
"""

import os
import pickle
import logging
import numpy as np
import pandas as pd
from datetime import datetime
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.model_selection import train_test_split
from sklearn.metrics import (mean_absolute_error,
                             mean_squared_error, r2_score)

from utils import (generate_initial_dataset, preprocess,
                   TARGET_COL, FEATURE_COLS)

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

MODEL_PATH   = "model.pkl"
DATA_PATH    = "live_data.csv"
META_PATH    = "model_meta.pkl"

# ─── Model registry ─────────────────────────────────────────────────────────

def _build_model(name: str = "rf"):
    if name == "rf":
        return RandomForestRegressor(
            n_estimators=200, max_depth=12,
            min_samples_leaf=3, n_jobs=-1, random_state=42)
    elif name == "gbm":
        return GradientBoostingRegressor(
            n_estimators=200, learning_rate=0.05,
            max_depth=5, random_state=42)
    elif name == "ridge":
        return Ridge(alpha=10.0)
    raise ValueError(f"Unknown model: {name}")


# ─── Training ────────────────────────────────────────────────────────────────

def train(df: pd.DataFrame = None, model_name: str = "rf") -> dict:
    """
    Train (or retrain) the model.
    If df is None, generates fresh synthetic data + loads existing CSV.
    Returns a metrics dict.
    """
    # ── 1. Load / merge data ──────────────────────────────────────────────
    if df is None:
        if os.path.exists(DATA_PATH):
            df = pd.read_csv(DATA_PATH)
            log.info(f"Loaded {len(df)} rows from {DATA_PATH}")
        else:
            log.info("No CSV found — generating initial dataset …")
            df = generate_initial_dataset(n=600)
            df.to_csv(DATA_PATH, index=False)
            log.info(f"Saved {len(df)} rows to {DATA_PATH}")
    else:
        # Append new rows to existing CSV
        if os.path.exists(DATA_PATH):
            old = pd.read_csv(DATA_PATH)
            df  = pd.concat([old, df], ignore_index=True).drop_duplicates()
        df.to_csv(DATA_PATH, index=False)

    # ── 2. Feature engineering ────────────────────────────────────────────
    df = df.dropna(subset=[TARGET_COL])
    X, encoder, scaler = preprocess(df, fit=True)
    y = df[TARGET_COL].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42)

    # ── 3. Train ──────────────────────────────────────────────────────────
    model = _build_model(model_name)
    model.fit(X_train, y_train)

    # ── 4. Evaluate ───────────────────────────────────────────────────────
    preds = model.predict(X_test)
    mae   = mean_absolute_error(y_test, preds)
    rmse  = np.sqrt(mean_squared_error(y_test, preds))
    r2    = r2_score(y_test, preds)

    metrics = {
        "mae":        round(mae, 0),
        "rmse":       round(rmse, 0),
        "r2":         round(r2, 4),
        "n_train":    len(X_train),
        "n_test":     len(X_test),
        "model_type": model_name,
        "trained_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    log.info(f"Train complete | MAE={mae:,.0f} | R²={r2:.4f}")

    # ── 5. Persist ────────────────────────────────────────────────────────
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)
    with open(META_PATH, "wb") as f:
        pickle.dump({"encoder": encoder, "scaler": scaler,
                     "metrics": metrics}, f)

    log.info(f"Model saved → {MODEL_PATH}")
    return metrics


# ─── Inference ───────────────────────────────────────────────────────────────

def load_model():
    """Return (model, encoder, scaler, metrics) from disk."""
    if not os.path.exists(MODEL_PATH):
        log.info("No saved model found — training now …")
        train()
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    with open(META_PATH, "rb") as f:
        meta = pickle.load(f)
    return model, meta["encoder"], meta["scaler"], meta["metrics"]


def predict_price(features: dict) -> float:
    """
    features keys: area_sqyd, bedrooms, bathrooms, year_built,
                   floors, garage, has_garden, location
    Returns predicted price in PKR.
    """
    model, encoder, scaler, _ = load_model()
    row = pd.DataFrame([features])
    X, _, _ = preprocess(row, encoder=encoder, scaler=scaler, fit=False)
    price = model.predict(X)[0]
    return max(0.0, round(price, -3))


# ─── CLI entry point ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    metrics = train()
    print("\n── Model Training Complete ──────────────────────────────")
    for k, v in metrics.items():
        print(f"  {k:<14}: {v}")
