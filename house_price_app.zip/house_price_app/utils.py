"""
utils.py — Helpers for data simulation, preprocessing, and trend analysis
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import random

# ─── Simulated Real-Time Data Engine ────────────────────────────────────────

LOCATIONS = ["DHA", "Gulberg", "Model Town", "Bahria Town", "Johar Town",
             "Cantt", "Wapda Town", "Garden Town", "Faisal Town", "Iqbal Town"]

BASE_PRICES = {
    "DHA":          45_000,
    "Gulberg":      38_000,
    "Model Town":   30_000,
    "Bahria Town":  25_000,
    "Johar Town":   22_000,
    "Cantt":        40_000,
    "Wapda Town":   20_000,
    "Garden Town":  28_000,
    "Faisal Town":  18_000,
    "Iqbal Town":   16_000,
}  # PKR per sq ft


def simulate_one_record(noise_level: float = 0.08) -> dict:
    """Generate one realistic synthetic house listing."""
    location = random.choice(LOCATIONS)
    area = random.randint(3, 20) * 50          # 150–1000 sq yd
    bedrooms = random.randint(2, 7)
    bathrooms = random.randint(1, bedrooms)
    year_built = random.randint(1990, 2024)
    floors = random.randint(1, 3)
    garage = random.choice([0, 1])
    has_garden = random.choice([0, 1])

    area_sqft = area * 9                       # 1 sq yd ≈ 9 sq ft
    base = BASE_PRICES[location]
    age_discount = max(0, (2024 - year_built) * 0.003)
    noise = 1 + random.uniform(-noise_level, noise_level)

    price = (
        base * area_sqft
        + bedrooms * 400_000
        + bathrooms * 150_000
        + floors * 300_000
        + garage * 500_000
        + has_garden * 200_000
    ) * (1 - age_discount) * noise

    return {
        "timestamp":  datetime.now().isoformat(timespec="seconds"),
        "location":   location,
        "area_sqyd":  area,
        "bedrooms":   bedrooms,
        "bathrooms":  bathrooms,
        "year_built": year_built,
        "floors":     floors,
        "garage":     garage,
        "has_garden": has_garden,
        "price_pkr":  round(price, -3),
    }


def generate_initial_dataset(n: int = 500) -> pd.DataFrame:
    """Generate a warm-start dataset for the first model training."""
    random.seed(42)
    np.random.seed(42)
    records = [simulate_one_record(noise_level=0.10) for _ in range(n)]
    df = pd.DataFrame(records)
    # spread timestamps over the past 30 days
    base_time = datetime.now() - timedelta(days=30)
    df["timestamp"] = [
        (base_time + timedelta(minutes=i * 86)).isoformat(timespec="seconds")
        for i in range(n)
    ]
    return df


# ─── Preprocessing ──────────────────────────────────────────────────────────

FEATURE_COLS = ["area_sqyd", "bedrooms", "bathrooms",
                "year_built", "floors", "garage", "has_garden", "location"]
TARGET_COL   = "price_pkr"
CATEGORICAL   = ["location"]
NUMERICAL     = ["area_sqyd", "bedrooms", "bathrooms",
                 "year_built", "floors", "garage", "has_garden"]


def preprocess(df: pd.DataFrame, encoder=None, scaler=None, fit: bool = False):
    """
    Returns (X_array, encoder, scaler).
    If fit=True, fits encoder/scaler on df; otherwise transforms only.
    """
    from sklearn.preprocessing import StandardScaler, LabelEncoder

    df = df[FEATURE_COLS].copy()
    df[NUMERICAL] = df[NUMERICAL].fillna(df[NUMERICAL].median())
    df[CATEGORICAL] = df[CATEGORICAL].fillna("Unknown")

    if fit:
        encoder = {col: LabelEncoder() for col in CATEGORICAL}
        scaler  = StandardScaler()
        for col in CATEGORICAL:
            df[col] = encoder[col].fit_transform(df[col])
        X = scaler.fit_transform(df[NUMERICAL + CATEGORICAL])
    else:
        for col in CATEGORICAL:
            known = set(encoder[col].classes_)
            df[col] = df[col].apply(lambda v: v if v in known else encoder[col].classes_[0])
            df[col] = encoder[col].transform(df[col])
        X = scaler.transform(df[NUMERICAL + CATEGORICAL])

    return X, encoder, scaler


# ─── Trend Analytics ────────────────────────────────────────────────────────

def compute_trends(df: pd.DataFrame) -> dict:
    """Return summary stats used by the dashboard."""
    latest = df.tail(50)
    avg_by_loc = (
        df.groupby("location")["price_pkr"]
        .mean()
        .sort_values(ascending=False)
        .round(-3)
        .to_dict()
    )
    recent_prices = (
        df.sort_values("timestamp")
        .tail(30)[["timestamp", "price_pkr", "location"]]
        .to_dict(orient="records")
    )
    return {
        "avg_price":      round(df["price_pkr"].mean(), -3),
        "median_price":   round(df["price_pkr"].median(), -3),
        "total_listings": len(df),
        "avg_by_location": avg_by_loc,
        "recent_prices":   recent_prices,
        "last_updated":    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
